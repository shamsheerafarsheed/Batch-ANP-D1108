package StreamAPI;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/* 
 * Used to process Collection of objects
 * it will support various methods to produce desired output
 * 1.Map-->used to return stream of consisisting of the result applying a given function
 * 2.Filter-->used to select elements as per demand
 * 3.Sorted-->used to order the stream
 * 4.Collect:used to return the result that performed on the stream
 * 5.Foreach-->iterate data from stream
 * 6.Count
 */
public class StreamAPIDemo {

	public static void main(String[] args) {
		//creating list of integer
		List<Integer>marks=Arrays.asList(23,40,45,36,39);
		//Demonstrating map method
		List<Integer>updatedmarks=marks.stream().map(x->x+5).collect(Collectors.toList());
		System.out.println(updatedmarks);
		//Filter method
		List<String>name=Arrays.asList("Bipasha","Akif","Charan","Anusha","Arfa","Sumayya");
		List<String>filter_name=name.stream().filter(s->s.startsWith("A")).collect(Collectors.toList());
		System.out.println(filter_name);
		//sort method
		List<String>sorted_name=name.stream().sorted().collect(Collectors.toList());
		System.out.println(sorted_name);
		
		//foreach
		marks.stream().map(x->x*10).forEach(y->System.out.println(y));

	}

}
