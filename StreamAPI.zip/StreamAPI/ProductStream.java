package StreamAPI;

import java.util.*;
import java.util.stream.Collectors;

class Product
{
	int id;
	String name;
	double price;
	Product(int id,String name,double price)
	{
	this.id=id;
	this.name=name;
	this.price=price;
	}
}
public class ProductStream {

	public static void main(String[] args) {
		List<Product>prdct=new ArrayList<>();
		//Add Product
		prdct.add(new Product(1,"Asus",48000));
		prdct.add(new Product(2,"Dell",50000));
		
		prdct.add(new Product(3,"HP",60000));
		
		prdct.add(new Product(4,"Lenovo",78000));
		List<Double>productPriceList=prdct.stream().filter(p->p.price>50000).map(p->p.price).collect(Collectors.toList());
		System.out.println(productPriceList);
		prdct.stream().filter(p->p.price>50000).forEach(product->System.out.println(product.name));
		
		
	}

}
