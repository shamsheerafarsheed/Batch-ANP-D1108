package StreamAPI;



import java.util.*;
import java.util.stream.*;
import java.util.function.*;

class Employee {
    int id;
    String name;
    String department;
    double salary;

    public Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String toString() {
        return id + " - " + name + " - " + department + " - ₹" + salary;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

    public String getName() {
        return name;
    }
}

public class EmployeeStream {


    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee(101, "Alice", "HR", 48000),
            new Employee(102, "Bob", "IT", 75000),
            new Employee(103, "Charlie", "Finance", 65000),
            new Employee(104, "David", "IT", 82000),
            new Employee(105, "Eva", "HR", 51000)
        );

        // 1️⃣ Filter employees with salary > 50,000 and print them
        System.out.println("Employees with salary > 50,000:");
        employees.stream()
                 .filter(emp -> emp.getSalary() > 50000)
                 .forEach(System.out::println);

        // 2️⃣ Get names of all employees in IT department
        System.out.println("\nNames of IT Department employees:");
        List<String> itNames = employees.stream()
                                        .filter(emp -> emp.getDepartment().equals("IT"))
                                        .map(Employee::getName)
                                        .collect(Collectors.toList());
        System.out.println(itNames);

        // 3️⃣ Count number of employees in HR department
        long hrCount = employees.stream()
                                .filter(emp -> emp.getDepartment().equals("HR"))
                                .count();
        System.out.println("\nNumber of HR employees: " + hrCount);

        // 4️⃣ Find highest-paid employee
        Employee highestPaid = employees.stream()
                                        .max(Comparator.comparingDouble(Employee::getSalary))
                                        .orElse(null);
        System.out.println("\nHighest paid employee: " + highestPaid);

        // 5️⃣ Group employees by department
        System.out.println("\nEmployees grouped by department:");
        Map<String, List<Employee>> grouped = employees.stream()
                                                       .collect(Collectors.groupingBy(Employee::getDepartment));
        grouped.forEach((dept, emps) -> {
            System.out.println(dept + ": " + emps);
        });
    }
}
