package MultiThreadingDemo;




class TicketCounter {
    int tickets = 5;

    // Synchronized method to avoid race condition
    public synchronized void bookTicket(String name) {
        if (tickets > 0) {
            System.out.println(name + " booked 1 ticket.");
            tickets--;
        } else {
            System.out.println(name + " - No tickets available.");
        }
    }
}

class BookingThread extends Thread {
    TicketCounter counter;
    String customerName;

    BookingThread(TicketCounter counter, String customerName) {
        this.counter = counter;
        this.customerName = customerName;
    }

    public void run() {
        counter.bookTicket(customerName);
    }
}

public class TicketBookingSystem {
    public static void main(String[] args) {
        TicketCounter counter = new TicketCounter();

        BookingThread t1 = new BookingThread(counter, "User 1");
        BookingThread t2 = new BookingThread(counter, "User 2");
        BookingThread t3 = new BookingThread(counter, "User 3");
        BookingThread t4 = new BookingThread(counter, "User 4");
        BookingThread t5 = new BookingThread(counter, "User 5");
        BookingThread t6 = new BookingThread(counter, "User 6");

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
    }
}