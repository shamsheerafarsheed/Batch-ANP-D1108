package MultiThreadingDemo;

public class TicketBooking extends Thread {
    static int tickets = 5;

    public void run() {
        if (tickets > 0) {
            System.out.println(Thread.currentThread().getName() + " booked 1 ticket.");
            tickets--;
        } else {
            System.out.println(Thread.currentThread().getName() + " - No tickets available.");
        }
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            TicketBooking t = new TicketBooking();
            t.setName("User " + i);
            t.start();
        }
    }
}
