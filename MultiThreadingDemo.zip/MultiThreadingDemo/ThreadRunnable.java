package MultiThreadingDemo;

public class ThreadRunnable implements Runnable{
	@Override
	public void run() {
		System.out.println("Runnable interface Thread is running...");
	}

	public static void main(String[] args) {
		
		ThreadRunnable t1=new ThreadRunnable();
		Thread r1=new Thread(t1);//pass runnable objects to thread
		r1.start();
		//Life cycle
		/*1.New--thread object  created
		 * 2.Runnable--->strat() is called,ready to run
		 * 3.Running-->executing run()
		 * 4.Waiting-->waiting for resources
		 * 5.Dead-->run() method is completed
		 */
		
		

	}

	

}
