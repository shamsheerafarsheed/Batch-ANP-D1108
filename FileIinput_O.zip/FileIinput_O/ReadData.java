package FileIinput_O;

import java.io.FileInputStream;

public class ReadData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			//for read data
		FileInputStream inp=new FileInputStream("anudip.txt");
		//read first byte(deserialization)
		
		int i=inp.read();
		while(i!=-1)
		{
			System.out.println((char)i);
			//read next byte from file
			i=inp.read();
		}
		inp.close();
		}
		catch(Exception e)
		{
			System.out.println("Error occured");
		}
		
	}

	}


