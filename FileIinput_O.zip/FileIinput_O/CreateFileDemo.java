package FileIinput_O;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

//write---file output stream
//read---file input stream
public class CreateFileDemo {
	public static void main(String[] args) throws IOException{
		///Represent the file
		File file=new File("Anudip.txt");
		if(file.exists())
		{
			
			file.createNewFile();//file will create
		}
		FileOutputStream fos=new FileOutputStream(file);
		
String data="Welcome to the PIJ session";
//Serialization
fos.write(data.getBytes());
fos.flush();//it will remove all data present in the writer
System.out.println("Absolute path: " + file.getAbsolutePath());
System.out.println("Absolute path: " + file.getCanonicalFile());
System.out.println("Relative path: " + file.getPath());
	}


}
