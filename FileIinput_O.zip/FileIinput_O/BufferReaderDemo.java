package FileIinput_O;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferReaderDemo {

	public static void main(String[] args) {
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("sample.txt"))) {
            writer.write("This is an example using BufferedWriter.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("sample.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

	}

}
