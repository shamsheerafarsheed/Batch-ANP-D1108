package FileIinput_O;

import java.io.*;
import java.util.Scanner;

public class UserDataStorage {
    private static final String FILE_NAME = "users.txt";

    // Method to save user data to file
    public static void saveUser(String name, String email, int age) {
        try (FileWriter fw = new FileWriter(FILE_NAME, true); // true = append mode
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {

            out.println(name + "," + email + "," + age);
            System.out.println(" User data saved successfully!");

        } catch (IOException e) {
            System.out.println(" Error writing to file.");
            e.printStackTrace();
        }
    }

    // Method to read all users from file
    public static void readUsers() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            System.out.println(" No user data found.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            System.out.println("\n--- Stored Users ---");
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                System.out.println("Name: " + data[0] + ", Email: " + data[1] + ", Age: " + data[2]);
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading file.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add User");
            System.out.println("2. View Users");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            if (choice == 1) {
                System.out.print("Enter Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Email: ");
                String email = sc.nextLine();

                System.out.print("Enter Age: ");
                int age = sc.nextInt();

                saveUser(name, email, age);
            } else if (choice == 2) {
                readUsers();
            } else {
                System.out.println("Exiting...");
                break;
            }
        }

        sc.close();
    }
}

