package LambdaDemo;



	
		interface addNumber
		{
			//functional interface(only 1 method)
			void add(int x,int y);
		}
		
		public class AddTwoNum_Lambda {
			public static void main(String[] args) {
				//we cant create object of JavaDemo interface but we can create reference object 
				
				addNumber obj;
				
				//Lambda expression
				obj=(x,y)->System.out.println(x+y);
				
			
			
				obj.add(15,8);
			}

}
