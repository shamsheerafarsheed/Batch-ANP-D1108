package LambdaDemo;


import java.util.*;
import java.util.stream.Collectors;
import java.time.LocalDate;

class Order {
    int id;
    double amount;
    LocalDate orderDate;

    public Order(int id, double amount, LocalDate orderDate) {
        this.id = id;
        this.amount = amount;
        this.orderDate = orderDate;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", amount=" + amount +
                ", orderDate=" + orderDate +
                '}';
    }
}

public class RealtimeLambda {


    public static void main(String[] args) {
        List<Order> orders = Arrays.asList(
            new Order(101, 15000, LocalDate.of(2025, 8, 10)),
            new Order(102, 9000, LocalDate.of(2025, 8, 5)),
            new Order(103, 12000, LocalDate.of(2025, 8, 8)),
            new Order(104, 7000, LocalDate.of(2025, 8, 1))
        );

        // 1️⃣ Filter high-value orders using Lambda
        List<Order> highValueOrders = orders.stream()
                .filter(o -> o.amount > 10000).collect(Collectors.toList()); // Lambda as Predicate
                

        // 2️⃣ Sort by order date using Lambda
        highValueOrders = highValueOrders.stream()
                .sorted((o1, o2) -> o1.orderDate.compareTo(o2.orderDate)).collect(Collectors.toList()); // Lambda as Comparator
                

        // 3️⃣ Print orders using Lambda
        highValueOrders.forEach(o -> System.out.println(o)); // Lambda as Consumer
    }
}
