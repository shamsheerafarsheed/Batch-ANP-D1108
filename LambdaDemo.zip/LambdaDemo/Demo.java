package LambdaDemo;
/*
 * use implementing functional interface(an interface having only one method)
 * short block of code
 * it doesnt have a name,we can directly implement in the body
 * it will take parameter as well as return the value
 * 3 components
 * 1.Argument list
 * 2.Arrow Token(->)
 * 3.Body/expression(
 * p1,p2)->expression
 */ 
interface JavaDemo
{
	//functional interface(only 1 method)
	void show(String x,int y);
}
//class a created for implementing interface
/*class A implements JavaDemo
{

	@Override
	public void show() {
		System.out.println("welcome");
		
	}
	
}*/
public class Demo {

	public static void main(String[] args) {
		//we cant create object of JavaDemo interface but we can create reference object 
		
		JavaDemo obj;
		/*
		 * Anonymous class 
		 * obj=new JavaDemo()
				{
			public void show() {
				System.out.println("welcome");
				
			}
				};*/
		//Lambda expression
		obj=(x,y)->System.out.println("welcome"+ x+y);
		
	
	
		obj.show(" To java",8);
	}

}
