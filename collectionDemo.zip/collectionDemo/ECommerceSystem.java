package collectionDemo;
import java.util.*;
public class ECommerceSystem {
	


	    public static void main(String[] args) {
	        
	        // 1. HashMap for storing user login credentials
	        Map<String, String> userLogins = new HashMap<>();
	        userLogins.put("john_doe", "password123");
	        userLogins.put("alice", "alice@2025");
	        userLogins.put("bob", "b0b_secure");
	        System.out.println("User Logins (HashMap): " + userLogins);

	        // Simulating user login
	        String username = "alice";
	        if (userLogins.containsKey(username)) {
	            System.out.println(username + " logged in successfully.");
	        }

	        // 2. LinkedHashMap for maintaining user browsing history (in order)
	        Map<Integer, String> browsingHistory = new LinkedHashMap<>();
	        browsingHistory.put(1, "Home");
	        browsingHistory.put(2, "Products");
	        browsingHistory.put(3, "Cart");
	        browsingHistory.put(4, "Checkout");
	        System.out.println("\nBrowsing History (LinkedHashMap): " + browsingHistory);

	        // 3. TreeMap for storing product catalog sorted by product ID
	        Map<Integer, String> productCatalog = new TreeMap<>();
	        productCatalog.put(103, "Tablet");
	        productCatalog.put(101, "Laptop");
	        productCatalog.put(102, "Smartphone");
	        System.out.println("\nProduct Catalog (TreeMap - Sorted by ID): " + productCatalog);

	        // Simulating product search
	        int searchId = 102;
	        System.out.println("Product searched (ID " + searchId + "): " + productCatalog.get(searchId));

	        // 4. Hashtable for application settings (thread-safe configuration)
	        Map<String, String> appSettings = new Hashtable<>();
	        appSettings.put("theme", "dark");
	        appSettings.put("timeout", "30");
	        appSettings.put("language", "English");
	        System.out.println("\nApplication Settings (Hashtable): " + appSettings);

	        // Using settings in application
	        System.out.println("Current App Theme: " + appSettings.get("theme"));
	    }
	}

/*
 * HashMap → Stores and validates user login credentials.

LinkedHashMap → Maintains the exact order of user’s browsing history.

TreeMap → Keeps product catalog sorted by Product ID.

Hashtable → Stores app configuration in a thread-safe way.

*/