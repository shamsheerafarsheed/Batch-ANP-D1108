package collectionDemo;
import java.util.*;
public class SortedMapDemo {

	public static void main(String[] args) {
		SortedMap<Integer,String> SM=new TreeMap<>();
		SM.put(4, "Rahul");
		SM.put(1, "Sourabh");
		SM.put(2, "Rahul");
		SM.put(4, "Tejshri");
		System.out.println(SM.entrySet());
		String a=SM.remove(1);
		System.out.println(SM.entrySet());
		// Check existence
        System.out.println("Contains key 1? " + SM.containsKey(2));
		

	}

}
