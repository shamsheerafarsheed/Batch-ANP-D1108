package collectionDemo;

import java.util.*;
/*
 * Preserves the order in which entries were inserted.

Useful for ordered caching.
 */
public class LinkedHasMapDemo {
	public static void main(String[] args) {
        Map<Integer, String> pageCache = new LinkedHashMap<>();

        // Adding pages in the order visited
        pageCache.put(1, "Home");
        pageCache.put(2, "Products");
        pageCache.put(3, "Cart");
        pageCache.put(4, "Checkout");

        // Display pages in the order visited
        System.out.println("Page visit order: " + pageCache);
    }

}
