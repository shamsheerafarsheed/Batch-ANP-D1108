package collectionDemo;
/*
 * Keeps keys in sorted order automatically.

Great for creating sorted reports or leaderboards.
 */
import java.util.*;

public class TreeMapEx {

	public static void main(String[] args) {
		Map<Integer, String> employeeDirectory = new TreeMap<>();

        // Adding employee data (will be stored sorted by ID)
        employeeDirectory.put(103, "Chandana");
        employeeDirectory.put(101, "Anusha");
        employeeDirectory.put(102, "Beena");

        // Displaying sorted employee directory
        System.out.println("Sorted Employee Directory: " + employeeDirectory);

	}

}
