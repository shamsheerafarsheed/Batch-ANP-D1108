package collectionDemo;
import java.util.HashMap;
import java.util.Map;
/*
 * Fast search for usernames.

Order does not matter.
 */
public class HashMapEx {
	
	
	    public static void main(String[] args) {
	        Map<String, String> loginCredentials = new HashMap<>();

	        // Adding username-password pairs
	        loginCredentials.put("john_doe", "password123");
	        loginCredentials.put("diya", "diya@2025");
	        loginCredentials.put("binu", "binu_secure");

	        // Retrieving password by username
	        System.out.println("Password of alice: " + loginCredentials.get("diya"));
	    }
	
}
