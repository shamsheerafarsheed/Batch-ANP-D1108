package collectionDemo;

import java.util.*;

public class HashTableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Map<String, String> appSettings = new Hashtable<>();

	        // Adding settings
	        appSettings.put("theme", "dark");
	        appSettings.put("timeout", "30");
	        appSettings.put("language", "English");

	        // Retrieving a setting
	        System.out.println("App Theme: " + appSettings.get("theme"));
	    }

	}

/*
 * Thread-safe (synchronized).

Useful in legacy multi-threaded environments.*/
